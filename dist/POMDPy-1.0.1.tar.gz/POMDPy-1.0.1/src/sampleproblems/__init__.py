__author__ = 'patrickemami'

__all__ = ['RockProblem', 'TigerProblem']
