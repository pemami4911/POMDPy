__author__ = 'patrickemami'

__all__ = ['discrete_action', 'discrete_action_mapping', 'discrete_observation',
           'discrete_observation_mapping', 'discrete_state']